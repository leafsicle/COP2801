let x = 3
let total = x ** 2 - 4 * x + 7
//alternately let total = x * (x - 4) + 7
console.log(total)
