let hoursOpen = 4
let hour1 = 75
let hour2 = 96
let hour3 = 22
let hour4 = 108

let totalDailyCustCount = hour1 + hour2 + hour3 + hour4
let avgHourlyCustomer = totalDailyCustCount / hoursOpen
console.log(totalDailyCustCount + ' total guests for the day')
console.log(avgHourlyCustomer + ' Avg Cust per hour')
